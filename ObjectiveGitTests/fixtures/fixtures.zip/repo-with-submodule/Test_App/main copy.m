//
//  main.m
//  Test
//
//  Created by Joe Ricioppo on 9/28/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

1

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
123456789
123456789
123456789
123456789
12
123456789
12