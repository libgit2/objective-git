v0.1.5
======

* Shared examples
* Sanitize description on exception [meiwin]

v0.1.4
======

* Pending specs
* Include SpectaTypes.h in the build output [strangemonad]

v0.1.3
======

* Fixed unexpected exceptions not being caught in iOS4 simulator
* Map unexpected exceptions to correct spec file

v0.1.2
======

* Fixed compiled example names being incorrectly generated

v0.1.1
======

* Prevented SPTSenTest class from running

v0.1.0
======

* First Release

